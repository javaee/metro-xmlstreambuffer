/**
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.xml.stream;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.CharArrayReader;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;

import javax.xml.stream.*;
import javax.xml.stream.util.XMLEventAllocator ;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import com.sun.xml.stream.xerces.xni.parser.XMLInputSource;

/** Factory Implementation for XMLInputFactory.
 * @author Neeraj Bajaj Sun Microsystems
 * @author K.Venugopal Sun Microsystems
 */

//xxx: Should we be reusing the XMLInputSource object
public class ZephyrParserFactory extends javax.xml.stream.XMLInputFactory {
    
    protected static final String READER_IN_DEFINED_STATE = Constants.READER_IN_DEFINED_STATE;
    
    //List of supported properties and default values.
    private PropertyManager fPropertyManager = new PropertyManager(PropertyManager.CONTEXT_READER) ;
    private static final boolean DEBUG = false;
    
    //Maintain a reference to last reader instantiated.
    private XMLReaderImpl fTempReader = null ;
    
    boolean fPropertyChanged = false;
    //default value is true
    boolean fReuseInstance = true;
    //set this flag to true if EventReader instance is being created
    boolean fEventReaderInstance = false;
    
    /** Creates a new instance of ZephryParserFactory */
    public ZephyrParserFactory() {
        //fPropertyManager = new PropertyManager(PropertyManager.CONTEXT_READER) ;
    }
    
    void initEventReader(){
        fEventReaderInstance = true;
        fPropertyChanged = true;
    }
    /**
     * @param inputstream
     * @throws XMLStreamException
     * @return
     */
    public XMLEventReader createXMLEventReader(InputStream inputstream) throws XMLStreamException {
        initEventReader();
        //delegate everything to XMLStreamReader
        return new XMLEventReaderImpl(createXMLStreamReader(inputstream));
    }
    
    public XMLEventReader createXMLEventReader(Reader reader) throws XMLStreamException {
        initEventReader();
        //delegate everything to XMLStreamReader
        return new XMLEventReaderImpl(createXMLStreamReader(reader));
    }
    
    public XMLEventReader createXMLEventReader(Source source) throws XMLStreamException {
        initEventReader();
        //delegate everything to XMLStreamReader
        return new XMLEventReaderImpl(createXMLStreamReader(source));
    }
    
    public XMLEventReader createXMLEventReader(String systemId, InputStream inputstream) throws XMLStreamException {
        initEventReader();
        //delegate everything to XMLStreamReader
        return new XMLEventReaderImpl(createXMLStreamReader(systemId, inputstream));
    }
    
    public XMLEventReader createXMLEventReader(java.io.InputStream stream, String encoding) throws XMLStreamException {
        initEventReader();
        //delegate everything to XMLStreamReader
        return new XMLEventReaderImpl(createXMLStreamReader(stream, encoding));
    }
    
    public XMLEventReader createXMLEventReader(String systemId, Reader reader) throws XMLStreamException {
        initEventReader();
        //delegate everything to XMLStreamReader
        return new XMLEventReaderImpl(createXMLStreamReader(systemId, reader));
    }
    
    /** Create a new XMLEventReader from an XMLStreamReader.  After being used
     * to construct the XMLEventReader instance returned from this method
     * the XMLStreamReader must not be used.
     * @param reader the XMLStreamReader to read from (may not be modified)
     * @return a new XMLEventReader
     * @throws XMLStreamException
     */
    public XMLEventReader createXMLEventReader(XMLStreamReader reader) throws XMLStreamException {
        initEventReader();
        //xxx: what do we do now -- instance is passed from the application
        //probably we should check if the state is at the start document,
        //eventreader call to next() should return START_DOCUMENT and
        //then delegate every call to underlying streamReader
        return new XMLEventReaderImpl(reader) ;
    }
            
    public XMLStreamReader createXMLStreamReader(Reader reader) throws XMLStreamException {
        return createXMLStreamReader(null, reader);
    }
    
    public XMLStreamReader createXMLStreamReader(String systemId, Reader reader) throws XMLStreamException {        
        XMLInputSource inputSource = new XMLInputSource(null,systemId,null,reader,null);
        return getXMLStreamReaderImpl(inputSource);
    }
    
    public XMLStreamReader createXMLStreamReader(Source source) throws XMLStreamException {
        return new XMLReaderImpl(jaxpSourcetoXMLInputSource(source) , getNewPropertyManager());
    }
    
    public XMLStreamReader createXMLStreamReader(InputStream inputStream) throws XMLStreamException {
        return createXMLStreamReader(null, inputStream, null);
    }
    
    public XMLStreamReader createXMLStreamReader(String systemId, InputStream inputStream) throws XMLStreamException {
        return createXMLStreamReader(systemId, inputStream, null);
    }
    
    
    public XMLStreamReader createXMLStreamReader(InputStream inputStream, String encoding) throws XMLStreamException {
        return createXMLStreamReader(null, inputStream, encoding);
    }
    
    //API doesn't allow to set systemId and encoding simultaneously. I think that is a
    //mistake - Neeraj Bajaj
    //Making this function public in case any one wants to use.
    public XMLStreamReader createXMLStreamReader(String systemId, InputStream inputStream, String encoding) throws XMLStreamException {        
        XMLInputSource inputSource = new XMLInputSource(null,systemId,null,inputStream,encoding);
        return getXMLStreamReaderImpl(inputSource);
    }
    
    public XMLEventAllocator getEventAllocator() {
        return (XMLEventAllocator)getProperty(XMLInputFactory.ALLOCATOR);
    }
    
    public XMLReporter getXMLReporter() {
        return (XMLReporter)fPropertyManager.getProperty(XMLInputFactory.REPORTER);
    }
    
    public XMLResolver getXMLResolver() {
        Object object = fPropertyManager.getProperty(XMLInputFactory.RESOLVER);
        return (XMLResolver)object;
        //return (XMLResolver)fPropertyManager.getProperty(XMLInputFactory.RESOLVER);
    }
    
    public void setXMLReporter(XMLReporter xmlreporter) {
        fPropertyManager.setProperty(XMLInputFactory.REPORTER, xmlreporter);
    }
    
    public void setXMLResolver(XMLResolver xmlresolver) {
        fPropertyManager.setProperty(XMLInputFactory.RESOLVER, xmlresolver);
    }
    
    /** Create a filtered event reader that wraps the filter around the event reader
     * @param reader the event reader to wrap
     * @param filter the filter to apply to the event reader
     * @throws XMLStreamException
     */
    public XMLEventReader createFilteredReader(XMLEventReader reader, EventFilter filter) throws XMLStreamException {
        return new EventFilterSupport(reader, filter);
    }
    
    /** Create a filtered reader that wraps the filter around the reader
     * @param reader the reader to filter
     * @param filter the filter to apply to the reader
     * @throws XMLStreamException
     */
    public XMLStreamReader createFilteredReader(XMLStreamReader reader, StreamFilter filter) throws XMLStreamException {
        if( reader != null && filter != null )
            return new XMLStreamFilterImpl(reader,filter);
        
        return null;
    }
    
    
    
    /** Get the value of a feature/property from the underlying implementation
     * @param name The name of the property (may not be null)
     * @return The value of the property
     * @throws IllegalArgumentException if the property is not supported
     */
    public Object getProperty(java.lang.String name) throws java.lang.IllegalArgumentException {
        if(name == null){
            throw new IllegalArgumentException("Property not supported");
        }
        if(fPropertyManager.containsProperty(name))
            return fPropertyManager.getProperty(name);
        throw new IllegalArgumentException("Property not supported");
    }
    
    /** Query the set of fProperties that this factory supports.
     *
     * @param name The name of the property (may not be null)
     * @return true if the property is supported and false otherwise
     */
    public boolean isPropertySupported(String name) {
        if(name == null)
            return false ;
        else
            return fPropertyManager.containsProperty(name);
    }
    
    /** Set a user defined event allocator for events
     * @param allocator the user defined allocator
     */
    public void setEventAllocator(XMLEventAllocator allocator) {
        fPropertyManager.setProperty(XMLInputFactory.ALLOCATOR, allocator);
    }
    
    /** Allows the user to set specific feature/property on the underlying implementation. The underlying implementation
     * is not required to support every setting of every property in the specification and may use IllegalArgumentException
     * to signal that an unsupported property may not be set with the specified value.
     * @param name The name of the property (may not be null)
     * @param value The value of the property
     * @throws java.lang.IllegalArgumentException if the property is not supported
     */
    public void setProperty(java.lang.String name, Object value) throws java.lang.IllegalArgumentException {
        
        if(name == null || value == null || !fPropertyManager.containsProperty(name) ){
            throw new IllegalArgumentException("Property "+name+" is not supported");
        }
        if(name == Constants.REUSE_INSTANCE || name.equals(Constants.REUSE_INSTANCE)){
            fReuseInstance = ((Boolean)value).booleanValue();
            if(DEBUG)System.out.println("fReuseInstance is set to " + fReuseInstance);
        }else{//for any other property set the flag
            //REVISIT: Even in this case instance can be reused, by passing PropertyManager
            fPropertyChanged = true;
        }
        
        fPropertyManager.setProperty(name,value);
    }
    
    XMLStreamReader getXMLStreamReaderImpl(XMLInputSource inputSource) throws javax.xml.stream.XMLStreamException{
        //1. if the temp reader is null -- create the instance and return
        if(fTempReader == null){
            fPropertyChanged = false;
            if(DEBUG)System.out.println("New Instance is being returned");
            return fTempReader = new XMLReaderImpl(inputSource, getNewPropertyManager());
        }
        //if factory is configured to reuse the instance & this instance can be reused 
        //& the setProperty() hasn't been called
        if(fReuseInstance && fTempReader.canReuse() && !fPropertyChanged){
            if(DEBUG)System.out.println("Reusing the instance");
            //we can make setInputSource() call reset() and this way there wont be two function calls
            fTempReader.reset();
            fTempReader.setInputSource(inputSource);
            fPropertyChanged = false;
            return fTempReader;
        }else{
            fPropertyChanged = false;
            if(DEBUG)System.out.println("New Instance is being returned");
            //just return the new instance.. note that we are not setting  fTempReader to the newly created instance
            return fTempReader = new XMLReaderImpl(inputSource, getNewPropertyManager());
        }
    }

    PropertyManager getNewPropertyManager(){
        PropertyManager pm = new PropertyManager(fPropertyManager);
        if(fEventReaderInstance){
            //this  is really ugly.. event reader has to be in undefined state.
            //set this property for this new PropertyManager instance
            pm.setProperty(Constants.READER_IN_DEFINED_STATE, new Boolean(false));
            fEventReaderInstance = false;
            //xxx: if instance is reused, this instance will be in undefined state
            //set this flag to true so that this instance is not reused
            fPropertyChanged = true;
        }
        return pm;        
    }
    
    XMLInputSource jaxpSourcetoXMLInputSource(Source source){
        
        if(source instanceof StreamSource){
            StreamSource stSource = (StreamSource)source;
            String systemId = stSource.getSystemId();
            String publicId = stSource.getPublicId();
            InputStream istream = stSource.getInputStream();            
            Reader reader = stSource.getReader();
            
            
            if(istream != null){
                return new XMLInputSource(publicId, systemId, null, istream, null);
            }
            else if(reader != null){
                return new XMLInputSource(publicId, systemId,null, reader, null);
            }else{
                return new XMLInputSource(publicId, systemId, null);
            }
        }else if(source instanceof Source){
            return new XMLInputSource(null, source.getSystemId(), null);
        }
        else{
            throw new java.lang.UnsupportedOperationException(source.getClass().getName() + " type is not supported");
        }
    }
}//ZephyrParserFactory
