/*
 * XMLOutputSource.java
 *
 * Encapuslates the information about the source where
 * XML output needs to be written.
 *
 */

package com.sun.xml.stream.writers;

import java.io.OutputStream;
import java.io.Writer;

/**
 *
 * @author Neeraj Bajaj
 */
public class XMLOutputSource {
    
    /** Output Stream class to write bytes*/
    OutputStream os ;
    /** Writer for writing to character stream */
    Writer writer;
    
    String systemId;
    
    /** Creates a new instance of XMLOutputSource */
    public XMLOutputSource() {
    }
    
}
